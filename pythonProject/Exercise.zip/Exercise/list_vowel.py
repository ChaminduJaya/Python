vowel =['A','a','E','e','I','i','O','o','U','u']
print('Question: ',vowel)
Vowel_c=vowel[::2]
print(Vowel_c)
Vowel_s=vowel[1::2]
print(Vowel_s)
Vowel_T=Vowel_c+Vowel_s
print(Vowel_T)
Vowel_T.reverse()
print(Vowel_T)