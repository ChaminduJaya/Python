marks=[45,67,78,99]
print(int(sum(marks)/len(marks)))