if 2:
    print('2 is true')
if 0 :
    print('0 is true')
else:
    print('0  is false')
if not []:
    print('[] is false')
if not() :
    print('() is false')