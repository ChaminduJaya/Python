def sum():
    print('sum')
def sum(x,y): # can't overload in same name method. when same name overriden happen.clearlest method will run
    print('no overloading',x,y)
sum('d',8)

def avg():
    x=9
    y=7
    return x
print(avg(),type(avg()))
def avg():
    x=9
    y=7
    return x,y
print(avg(),type(avg()))
def list():
    x=[2,2,2,2]
    y=8
    return x,y
print(list(),type(list()))#([2,2,2,2],8)
print(list()[0])
def cham():
    return None
print(cham(), type(cham()))
def suma():
    print('hi')
print(type(suma()),suma())
def rata(country:'Srl lanka'):
    print(country)
rata('norway')