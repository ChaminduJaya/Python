import file1


def main():
    print('hey')


if __name__ == '__main__':
   # main()
    file1.test()
