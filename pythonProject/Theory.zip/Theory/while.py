while True:
    print('while true')
    break;
while 5:
    print('while true')
    break;
while 0:
    print('while true')
    break;
while []:
    print('while true')
    break;
while 5>6 or 7>6:
    print('while true')
    break;
i=0
while i<10:

    if i==9:
        break;
    i+=1
    if i==5:
       continue;
    print(i)
