class python:
    pass #can't keep class empty
class java: #different class can be created
    instance=67
    def __init__(self,name,age):
        self.name = name
        self.age =age
        self.instance=89
        print(name)
    def update(self,name,age):
        self.name=name
        self.age=age
        print(name,age)
    def manyArgs(self,*arg):
        print(arg[0])
        print(len(arg))
        print(arg)
        return arg[1]+arg[2]

obj= java('cham',17)
obj.update('ddffdss',6778)
asr=obj.manyArgs(1,2,3)
print(asr)
