def test():
    print("I'm file1")